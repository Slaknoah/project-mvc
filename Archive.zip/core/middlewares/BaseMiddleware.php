<?php
namespace app\core\middlewares;

abstract class BaseMiddleware
{
    abstract public function execute();
}