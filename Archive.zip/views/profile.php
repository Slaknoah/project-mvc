<?php
use app\core\View;
/** @var View $this  */
$this->title = 'Profile';
?>

<h1>Profile Page</h1>